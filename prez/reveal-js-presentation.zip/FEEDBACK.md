# Feedback for the run of 26-11-2019

## Déroulement

- Kata : Tennis kata : 1h30
  - Par groupe de 2
  - Avec récupération du projet d'un autre groupe après 1h
  - Bien pour la compréhension du turnover
  - Peut être redondant avec le Fruit Shop Kata
- Présentation théorique
  - Bien dans l'ensemble
  - Manque : 
    - ???
  - Exemples SOLID à revoir
- Kata : Fruit shop kata
  - Début fastidieux
  - Pas de tests pour la plupart des groupes
  - Code produit assez "sale"
  - Ne permet pas de s'exercer à l'écriture de code propre
  - Permet de voir d'où vient le code "legacy"
- Live coding Fruit shop kata
  - Plutôt bien pour montrer l méthode
  - Arrive trop tard dans la journée

## A Améliorer
- Exemples SOLID
- Commencer par le fruit shop kata (avec changement de PC)
- Faire un autre kata ensuite pour s'entrainer aux méthodes
- Demander à remplir le formulaire de retour